"""Rebuild the atlas from the editable 57 PNG frames (requires Pillow)."""
from pathlib import Path
import json
from PIL import Image, ImageDraw

root = Path(__file__).resolve().parent
spec = json.loads((root / 'animation.json').read_text(encoding='utf-8'))
out = root / 'rebuilt'
out.mkdir(exist_ok=True)
(out / 'previews').mkdir(exist_ok=True)
atlas = Image.new('RGBA', (1536, 1872))
for row, state in enumerate(spec['states']):
    for col in range(state['frame_count']):
        frame = Image.open(root / 'source' / 'frames' / state['name'] / f'{col + 1:02}.png').convert('RGBA')
        if frame.size != (192, 208):
            raise ValueError(f"Wrong frame size: {state['name']} {col + 1}")
        atlas.paste(frame, (col * 192, row * 208))
atlas.save(out / 'spritesheet.png')
atlas.save(out / 'spritesheet.webp', lossless=True, quality=100, method=6)
contact = Image.new('RGB', atlas.size, (48, 55, 65))
draw = ImageDraw.Draw(contact)
for row, state in enumerate(spec['states']):
    frames = [atlas.crop((c*192, row*208, (c+1)*192, (row+1)*208)) for c in range(state['frame_count'])]
    frames[0].save(out / 'previews' / (state['name'] + '.gif'), save_all=True, append_images=frames[1:], duration=state['preview_duration_ms'], loop=0, disposal=2)
    for c, frame in enumerate(frames):
        contact.paste(frame, (c*192, row*208), frame)
        draw.text((c*192+4, row*208+3), f"{state['name']} {c+1}", fill='white')
contact.save(out / 'contact-sheet.png')
print(out)
