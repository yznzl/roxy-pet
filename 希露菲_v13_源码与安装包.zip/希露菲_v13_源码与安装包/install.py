"""Install the bundled Sylphie v13 as a local Codex pet; uses only Python stdlib."""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
from datetime import datetime, timezone

SHA256 = 'cb3872fff4c40c3c51d9b4acf1f10f09e0c9ae9be54d9e8eca02607aa375f5c8'
NAME = '希露菲'
DESCRIPTION = '银白短发、蓝宝石耳坠和橄榄绿披肩的Q版精灵。'


def install(document=None, codex_home=None):
    package = Path(__file__).resolve().parent
    asset = package / 'assets' / 'spritesheet.webp'
    if asset.is_file():
        data = asset.read_bytes()
    else:
        doc = Path(document) if document else package / '把这个文件交给Codex安装.md'
        text = doc.read_text(encoding='utf-8-sig')
        match = re.search(r'^<!-- SYLPHIE_WEBP_BASE64_BEGIN -->\s*\n(.*?)^<!-- SYLPHIE_WEBP_BASE64_END -->', text, re.M | re.S)
        if not match:
            raise ValueError('说明中的内嵌图集缺失；请使用完整的原始 Markdown 文件。')
        data = base64.b64decode(''.join(match.group(1).split()), validate=True)
    if hashlib.sha256(data).hexdigest() != SHA256:
        raise ValueError('图集 SHA-256 不匹配，停止安装。')
    home = Path(codex_home or os.environ.get('CODEX_HOME') or Path.home() / '.codex').expanduser().resolve()
    pets = home / 'pets'
    matches = []
    if pets.is_dir():
        for folder in pets.iterdir():
            manifest = folder / 'pet.json'
            if not folder.is_dir() or not manifest.is_file():
                continue
            try:
                record = json.loads(manifest.read_text(encoding='utf-8-sig'))
            except (ValueError, OSError):
                continue
            if record.get('displayName') == NAME:
                matches.append((folder, record))
    if len(matches) > 1:
        raise ValueError('发现多个同名希露菲，请让用户选择目标，避免更新错误条目：' + ', '.join(str(p) for p, _ in matches))
    target, record = matches[0] if matches else (pets / 'silver-elf', {})
    if not target.resolve().is_relative_to(pets.resolve()):
        raise ValueError('目标目录指向 pets 目录外，停止安装。')
    if target.exists() and not matches:
        raise ValueError('silver-elf 目录已被其他内容占用；请先确认目标。')
    manifest = dict(record)
    manifest.update(id=target.name, displayName=NAME, description=DESCRIPTION, spritesheetPath='spritesheet.webp')
    sprite = target / 'spritesheet.webp'
    unchanged = sprite.is_file() and sprite.read_bytes() == data and record == manifest
    backup = None
    if not unchanged:
        if target.exists():
            stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
            backup = home / 'pet-backups' / (target.name + '-' + stamp)
            backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copytree(target, backup, symlinks=True)
        target.mkdir(parents=True, exist_ok=True)
        # Replace each file atomically; an existing pet has a complete backup.
        pending = target / '.spritesheet.webp.sylphie-install.tmp'
        pending.write_bytes(data)
        os.replace(pending, sprite)
        pending = target / '.pet.json.sylphie-install.tmp'
        pending.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        os.replace(pending, target / 'pet.json')
    result = {'installed': True, 'already_current': unchanged, 'pet_directory': str(target),
              'sha256': SHA256, 'backup_directory': str(backup) if backup else None,
              'next_step': 'Settings > Pets > Refresh，然后选择希露菲；CLI 可用 /pets 希露菲。'}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--document', help='完整安装说明 Markdown 路径；只有说明文件时使用')
    parser.add_argument('--codex-home', help='可选：目标 Codex 主目录；默认 CODEX_HOME 或 ~/.codex')
    args = parser.parse_args()
    install(args.document, args.codex_home)
