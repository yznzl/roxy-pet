# 希露菲 v13 源码与安装包

最省事的安装：将「把这个文件交给Codex安装.md」这个原始文件发给另一台电脑的 Codex，并说「按这份说明安装并启用希露菲」。它已内嵌完整图集，不需要同时发送源码文件夹。安装脚本只用 Python 标准库。

完整包包含：

- `assets/spritesheet.webp`：已在当前云端使用的最终 v13 图集，安装时原样复制。
- `pet.json`：本地清单模板；实际安装会复用唯一同名宠物的 ID。
- `install.py`：本地安装、同名复用、自动备份；不会删除其他宠物或变更云端。
- `source/spritesheet.png` 与 `source/frames/`：无损图集和九状态 57 张可编辑帧。
- `source/designs/`：九组对应的高分辨率设计原图。
- `animation.json`：行顺序、帧数和预览时长。
- `build.py`：从 57 帧重建图集并生成九组动图，需要 Pillow；输出到 `rebuilt/`。
- `previews/`：九状态总览和 GIF，便于交付检查。
- `service-validation.json`：原 v13 WebP 已通过的服务校验记录。
- `checksums.sha256`：文件完整性清单。

「源码」是可编辑 PNG 帧、设计原图、清单与构建/安装代码；没有 PSD 分层、矢量源稿或 Codex 应用程序源码。安装不用重建素材。当前版本仍含四姿态组成的左右跑循环。

完整文件夹安装可运行 `python install.py`；如需指定 Codex 主目录，使用 `python install.py --codex-home <目标目录>`。同名更新会保存原文件夹备份，位置由脚本返回。

文件安装完成后到 Settings > Pets > Refresh，选择「希露菲」。本地列表与云端 Pets 列表独立；不能仅凭云端 API 成功判断桌面已经出现。参考官方文档：https://learn.chatgpt.com/docs/pets 。

本包不自动修改当前这台电脑的宠物目录，不复制账号、token 或其他宠物。
