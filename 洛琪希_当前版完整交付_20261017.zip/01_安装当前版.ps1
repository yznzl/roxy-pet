﻿[CmdletBinding()]
param(
    [string]$CodexRoot,
    [switch]$CheckOnly
)

$ErrorActionPreference = 'Stop'
$expectedHashes = @{
    'spritesheet.webp' = '946835f048cd9c885130b3eba1bde2b7f45b25d2cb1c067bc1fc20094e0cae18'
    'pet.json' = '03854eef5498ef5a82558e87d2f603fc0e3425405dd54f3548a6edcbf59bd97b'
}
$sourceBytes = @{}
foreach ($name in $expectedHashes.Keys) {
    $source = Join-Path $PSScriptRoot $name
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "缺少文件：$source" }
    if ((Get-FileHash -Algorithm SHA256 -LiteralPath $source).Hash.ToLowerInvariant() -ne $expectedHashes[$name]) {
        throw "文件校验不一致：$name，请重新取得完整资源包。"
    }
    $sourceBytes[$name] = [IO.File]::ReadAllBytes($source)
}
$metadata = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'pet.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if ($metadata.id -ne 'blue-braid-witch' -or $metadata.spritesheetPath -ne 'spritesheet.webp') {
    throw '宠物配置与当前资源包不一致。'
}
if ($CheckOnly) {
    Write-Output '资源校验通过：roxy-no-frame01-smooth-20261017'
    Write-Output ('图集SHA256：' + $expectedHashes['spritesheet.webp'])
    return
}

if ([string]::IsNullOrWhiteSpace($CodexRoot)) {
    if (-not [string]::IsNullOrWhiteSpace($env:CODEX_HOME)) {
        $CodexRoot = $env:CODEX_HOME
        if (-not (Test-Path -LiteralPath $CodexRoot -PathType Container)) { throw 'CODEX_HOME目录不存在。' }
    } else {
        $CodexRoot = Join-Path ([Environment]::GetFolderPath('UserProfile')) '.codex'
    }
}
$resolvedRoot = [IO.Path]::GetFullPath($CodexRoot)
$targetDir = [IO.Path]::Combine($resolvedRoot, 'pets', 'blue-braid-witch')
$backupRoot = Join-Path $resolvedRoot 'pet-backups'
if (-not $targetDir.StartsWith($resolvedRoot.TrimEnd('\', '/') + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
    throw '目标目录超出指定Codex目录。'
}
if (Test-Path -LiteralPath $targetDir) {
    $item = Get-Item -LiteralPath $targetDir -Force
    if (-not $item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
        throw '目标宠物目录不是普通目录，请先确认路径。'
    }
}
$previous = @{}
$same = $true
foreach ($name in $expectedHashes.Keys) {
    $destination = Join-Path $targetDir $name
    if (Test-Path -LiteralPath $destination) {
        $item = Get-Item -LiteralPath $destination -Force
        if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
            throw "目标不是普通文件：$destination"
        }
        $previous[$name] = [IO.File]::ReadAllBytes($destination)
        if ((Get-FileHash -Algorithm SHA256 -LiteralPath $destination).Hash.ToLowerInvariant() -ne $expectedHashes[$name]) { $same = $false }
    } else {
        $previous[$name] = $null
        $same = $false
    }
}
if ($same) { Write-Output "已经是相同版本：$targetDir"; return }

function Write-RoxyFile([string]$Path, [byte[]]$Bytes) {
    $temporary = Join-Path ([IO.Path]::GetDirectoryName($Path)) ('.roxy-' + [Guid]::NewGuid().ToString('N') + '.tmp')
    try {
        [IO.File]::WriteAllBytes($temporary, $Bytes)
        if ([IO.File]::Exists($Path)) { [IO.File]::Replace($temporary, $Path, [NullString]::Value) }
        else { [IO.File]::Move($temporary, $Path) }
    } finally {
        if ([IO.File]::Exists($temporary)) { [IO.File]::Delete($temporary) }
    }
}

if (@($previous.Values | Where-Object { $null -ne $_ }).Count -gt 0) {
    # 备份放在pets外，避免被扫描成第二只宠物。
    $backupDir = Join-Path $backupRoot ('blue-braid-witch-' + [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffffffZ'))
    [IO.Directory]::CreateDirectory($backupDir) | Out-Null
    foreach ($name in $expectedHashes.Keys) {
        if ($null -ne $previous[$name]) { [IO.File]::WriteAllBytes((Join-Path $backupDir $name), $previous[$name]) }
    }
    Write-Output "原文件备份：$backupDir"
}
[IO.Directory]::CreateDirectory($targetDir) | Out-Null
$written = @()
try {
    foreach ($name in @('spritesheet.webp', 'pet.json')) {
        Write-RoxyFile -Path (Join-Path $targetDir $name) -Bytes $sourceBytes[$name]
        $written += $name
    }
    foreach ($name in $expectedHashes.Keys) {
        if ((Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $targetDir $name)).Hash.ToLowerInvariant() -ne $expectedHashes[$name]) {
            throw "安装回读不一致：$name"
        }
    }
} catch {
    for ($i = $written.Count - 1; $i -ge 0; $i--) {
        $name = $written[$i]
        $destination = Join-Path $targetDir $name
        if ($null -eq $previous[$name]) { [IO.File]::Delete($destination) }
        else { Write-RoxyFile -Path $destination -Bytes $previous[$name] }
    }
    throw
}
Write-Output "本地资源安装完成：$targetDir"
Write-Output '请按第2份说明刷新/选择宠物，并按需要导入目标账户宠物库。'
