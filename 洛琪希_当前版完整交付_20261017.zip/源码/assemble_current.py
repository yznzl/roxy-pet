"""复现当前版本最后一步组帧。Python3.10+和Pillow；只写源码/rebuild-output及源码/frames，不安装宠物。"""
from pathlib import Path
from PIL import Image,ImageDraw
import json,hashlib,shutil
W=Path(__file__).resolve().parent;PACKAGE=W.parent;O=W/'rebuild-output';O.mkdir(parents=True,exist_ok=True)
from compose_atlas import save_outputs,clear_transparent_rgb
base=clear_transparent_rgb(Image.open(W/'source-before-smooth.webp').convert('RGBA'))
assert hashlib.sha256((W/'source-before-smooth.webp').read_bytes()).hexdigest()=='2ab3eb020af09ea2cb33abf7039d1768a02bdd3ba49d7e2b4ddda494bd3a9240'
assert base.size==(1536,1872)
atlas=base.copy()
for row in (1,2):
    atlas.paste(base.crop((4*192,row*208,5*192,(row+1)*208)),(7*192,row*208))
    frames=[atlas.crop((i*192,row*208,(i+1)*192,(row+1)*208)) for i in range(8)]
    for i in range(8):assert frames[i].tobytes()!=frames[(i+1)%8].tobytes(),'Adjacent/loop repeat remains'
for row in range(9):
    for col in range(8):
        if (row,col) not in ((1,7),(2,7)):
            box=(col*192,row*208,(col+1)*192,(row+1)*208)
            assert atlas.crop(box).tobytes()==base.crop(box).tobytes()
save_outputs(atlas,O/'atlas.png',O/'spritesheet.webp')
encoded=Image.open(O/'spritesheet.webp').convert('RGBA');assert encoded.tobytes()==atlas.tobytes()
assert encoded.tobytes()==Image.open(PACKAGE/'spritesheet.webp').convert('RGBA').tobytes(), 'Rebuilt pixels differ from canonical asset'
contact=Image.new('RGBA',(1536,480),(245,245,245,255));d=ImageDraw.Draw(contact)
states=['idle','running-right','running-left','waving','jumping','failed','waiting','running','review'];counts=[6,8,8,4,5,8,6,6,6]
for row,(state,count) in enumerate(zip(states,counts)):
    p=W/'frames'/state;p.mkdir(parents=True,exist_ok=True);frames=[]
    for col in range(count):
        f=encoded.crop((col*192,row*208,(col+1)*192,(row+1)*208));f.save(p/f'{col:02d}.png')
        bg=Image.new('RGBA',(192,208),(245,245,245,255));bg.alpha_composite(f);frames.append(bg.convert('RGB'))
        if row in (1,2):contact.alpha_composite(f,(col*192,(row-1)*240+30))
    frames[0].save(O/f'{state}.gif',save_all=True,append_images=frames[1:],duration=120 if row in (1,2) else 180,loop=0,disposal=2)
    if row in (1,2):
        gif=Image.open(O/f'{state}.gif');assert gif.n_frames==8
        for i in range(8):gif.seek(i);assert gif.info['duration']==120
        d.text((8,(row-1)*240+8),state+' source order: 2,3,4,5,6,7,8,6',fill='black')
contact.save(O/'running-contact-sheet.png')
shutil.copy2(W/'source-before-smooth.webp',O/'backup-app-before.webp');shutil.copy2(PACKAGE/'pet.json',O/'pet.json')
checks={'sha256':hashlib.sha256((O/'spritesheet.webp').read_bytes()).hexdigest(),'source_frame_order_1based':[2,3,4,5,6,7,8,6],'changed_slots_1based':{'right':[8],'left':[8]},'all_other_cells_identical':True,'source_pixels_unmodified':True,'adjacent_and_loop_duplicate_frames':False,'preview_frame_count':8,'preview_each_frame_ms':120,'preview_cycle_ms':960,'original_first_frame_still_absent':True,'native_app_playback_checked':False}
(O/'checks.json').write_text(json.dumps(checks,indent=2),encoding='utf-8');print(json.dumps(checks))
