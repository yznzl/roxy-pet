# 洛琪希：在另一台电脑还原当前版

版本：`roxy-no-frame01-smooth-20261017`。交付日期：2026-10-17。

## 还原的是什么

文件夹根目录的 `spritesheet.webp` 和 `pet.json` 就是本机当前已安装的完整资源，直接复制或导入即可。安装脚本读取这两个普通文件；无需重新生成图片、Python、图像库或 API Key。图集哈希一致即可确认拿到同一版。

| 项目 | 本包内容 |
| --- | --- |
| 显示名 / 本地 ID | 洛琪希 / `blue-braid-witch` |
| 最终图集 SHA256 | `946835f048cd9c885130b3eba1bde2b7f45b25d2cb1c067bc1fc20094e0cae18` |
| 图集 / 单格 | WebP，1536×1872，8列9行 / 192×208 |
| 各行有效格数 | `[6,8,8,4,5,8,6,6,6]` |
| 左右跑画面 | 旧保留版的原帧序 `[2,3,4,5,6,7,8,6]` |
| 跑步参考预览 | 8帧，每帧120ms，一圈960ms；没有连续或首尾重复格 |

原第1帧已移除，原第6帧在两个不相邻位置复用。其他动作没有改。这里的“旧保留版原帧序”用于追溯，导入时直接使用根目录原始图集，不要再次删除、移动或补帧。

“一比一”的核验对象是图集像素、配置和帧布局。屏幕上的大小、动画调度及状态切换还会受目标应用版本、系统缩放和减弱动态效果设置影响。本机已经确认本地与应用库回读 RGBA 一致，但尚未直接检查原生实播，也未在另一台电脑实装。

## 1. 准备目标电脑

准备支持自定义宠物的桌面应用和接收者自己的登录账户。正式安装不需要 Python；只有想运行“源码”中的组装程序时才需要 Python 3.10+ 和 Pillow。

官方文档给出的桌面入口是 **Settings → Pets**，创建任务完成后使用 **Refresh** 刷新并选择宠物。实际菜单以目标版本为准。[OpenAI 官方 Pets 文档](https://learn.chatgpt.com/docs/pets)

本地资源与账户宠物库需要分别处理。官方文档说明桌面自定义宠物保存在本机，并不会自动同步到网页端；这次实际修复也发现，只覆盖本地文件可能仍出现“无法更新你的虚拟宠物”。因此按下面顺序完成本地恢复、目标账户导入和回读核对。[OpenAI 官方 Pets 文档](https://learn.chatgpt.com/docs/pets)

## 2. 检查交付文件

目录结构：

```text
洛琪希_当前版完整交付_20261017/
  spritesheet.webp                  最终安装用图集
  pet.json                         本地宠物配置
  01_安装当前版.ps1                Windows安装脚本
  02_其他电脑Codex接入说明.md      本说明
  03_新角色提示词优化总结.md       本次经验与可复用提示词
  版本与校验.json                  版本、格式与文件哈希
  源码/                            组装源码、所需输入图集与辅助模块
  预览/                            九种状态GIF与对照图
  验证记录/                        原版本的结构与视觉检查结果
```

在该文件夹打开 Windows PowerShell，运行：

```powershell
.\01_安装当前版.ps1 -CheckOnly
Get-FileHash -Algorithm SHA256 -LiteralPath '.\spritesheet.webp'
```

第一条只检查资源，不安装。第二条的结果必须等于本说明顶部的图集SHA256。`pet.json` 的哈希列在 `版本与校验.json`。文件不一致时停止，重新取得原文件；不要重新编码图片。

## 3. 本地安装：脚本或直接复制

### Windows脚本方式

```powershell
.\01_安装当前版.ps1
```

脚本读取已有 `CODEX_HOME`；未设置时使用当前用户的 `%USERPROFILE%\.codex`。如果设置了 `CODEX_HOME`，该目录应已存在并与目标应用一致。[官方环境变量说明](https://learn.chatgpt.com/docs/config-file/environment-variables)、[官方Windows目录说明](https://learn.chatgpt.com/docs/windows/windows-app)

也可显式指定目标应用的Codex目录，例如：

```powershell
.\01_安装当前版.ps1 -CodexRoot 'D:\MyCodexHome'
```

安装后的结构：

```text
<目标Codex home>/pets/blue-braid-witch/
  pet.json
  spritesheet.webp
```

脚本只操作这两个文件；相同版本会跳过。遇到不同旧文件，先备份到 `<目标Codex home>/pet-backups/blue-braid-witch-时间戳/`；写入出错时尝试还原已改文件。它不修改应用全局配置、登录信息、聊天或其他宠物。

### 直接复制方式，适用于没有PowerShell或脚本被系统策略阻止时

1. 找到目标应用实际使用的Codex home：Windows默认 `%USERPROFILE%\.codex`；macOS/Linux默认 `~/.codex`；设置了 `CODEX_HOME` 则以该目录为准。
2. 若已有 `pets/blue-braid-witch`，先把旧 `pet.json`、`spritesheet.webp` 备份到该home下的 `pet-backups`，避免备份被扫描成另一只宠物。
3. 创建 `pets/blue-braid-witch`，把本包根目录的两个同名文件原样放进去。
4. 再核对目标图集SHA256，进入应用Pets设置刷新并选择洛琪希。

不要把整个交付文件夹直接复制成宠物目录，也不要复制“源码”里的上版输入图集。真正用于安装的只有根目录两个资源文件。

以上目录结构和JSON字段来自本次实际运行的配置。不同版本若改变接口，先由目标Codex核对当前格式；不要静默重画或更改已确认的图集。

Windows桌面应用应使用原生Windows用户目录。WSL默认使用Linux用户目录，可能对应另一套配置。[官方Windows目录说明](https://learn.chatgpt.com/docs/windows/windows-app)

安装脚本不会自行选择账户宠物，也不会把本地文件上传到账户库。继续执行下一步以完成所需账户接入。

## 4. 导入目标账户的宠物库

在目标电脑的 Codex 聊天里，提供本包根目录 `spritesheet.webp` 的实际路径，复制下面这段指令：

```text
请将已提供的洛琪希最终图集导入这台电脑及我自己的宠物库，并选中它。

图集必须保持原文件，不重新生图、不改颜色、不改帧序、不升级图集布局。
预期SHA256：946835f048cd9c885130b3eba1bde2b7f45b25d2cb1c067bc1fc20094e0cae18。
现有v1图集：1536×1872，192×208单格，行有效帧数[6,8,8,4,5,8,6,6,6]。
名称：洛琪希。本地ID：blue-braid-witch。
描述：蓝紫双辫、蓝眼睛、黑色巫师帽和棕色披风的可爱魔女。

先读取配套接入说明，核对根目录图集与配置的哈希，按说明复制或运行安装脚本。
使用当前环境可用的Pets工具：读取相关分页、解析目标账户记录并确认is_custom=true，校验最终图集valid=true后准备上传。
若目标账户没有本次要安装的记录，创建一个由目标账户拥有的自定义宠物；若有明确匹配的现有自定义记录，更新其稳定ID。存在多个同名候选时先确认目标，不能随便覆盖。
不要使用发送者账户的pet_ ID作为我的目标ID。
上传完成后选中目标宠物，重新列出确认active状态。
确认本地两个文件与本包一致；下载应用库回读核对解码RGBA。
WebP若被服务重编码，允许字节哈希不同，但必须RGBA逐像素一致。
保留目标电脑的旧版备份，不创建独立桌宠窗口，不复制发送者登录信息。
如果没有所需工具、账户权限或自定义宠物入口，明确说明缺少哪一步，不要声称已完成同步。
```

本次使用的工具流程为 `list_pets → validate_pet_spritesheet → prepare_pet_upload → create_pet 或 update_pet → select_pet → list_pets → 下载回读核对`。工具前缀可能随环境变化，按名称和实际 schema 查找。新账户的云端稳定 ID 由服务产生；本地 `blue-braid-witch` 与云端 `pet_…` 是不同层的标识。

如果目标账户提供网页端 **Upload pet**，也可上传本包根目录原始 `spritesheet.webp`，然后核对该账户里的记录。官方当前网页格式要求透明 PNG/WebP、1536×1872、不超过20MiB；本包符合这个现有 v1 格式。网页上传与桌面本地安装仍应各自确认。[OpenAI 官方 Pets 文档](https://learn.chatgpt.com/docs/pets)

## 5. 完成核对

确认这四件事再说“一比一还原完成”：

1. 本地 `spritesheet.webp` 的 SHA256 等于本说明顶部值；`pet.json` 的哈希与 `版本与校验.json` 一致。
2. 目标账户的洛琪希为自定义宠物，处于选中状态；没有错误覆盖其他同名记录。
3. 如执行账户导入，应用下载回读与本地图集的解码 RGBA 一致。
4. 在目标电脑实际观看左右跑、待机、跳跃及任务状态，确认没有白色棋盘底、裁切或加载旧缓存。记录“实播已看”与“只做文件检查”的区别。

若动画只显示静帧，检查系统是否启用了减弱动态效果；官方文档说明宠物会尊重该设置。[OpenAI 官方 Pets 文档](https://learn.chatgpt.com/docs/pets)

## 回退

停止本次覆盖操作，使用目标电脑 `pet-backups` 中保存的原 `spritesheet.webp` / `pet.json` 还原本地，再把原图集同步回目标账户原稳定 ID。若原本没有该宠物，按实际安装记录处理新增记录，不删除其他宠物。

不要用文件夹日期猜版本；用图集哈希和本次安装记录判定。

## 6. 维护源码与预览

`源码/assemble_current.py` 是本版最后一步组帧程序的可移植整理版；它读取同目录 `source-before-smooth.webp`，把左右跑末格换成原第6帧，并检查其余格不变。`compose_atlas.py` 是一并提供的原组装辅助模块。

需要复现最后一步时，在已具备Python3.10+和Pillow的环境运行：

```powershell
python ".\源码\assemble_current.py"
```

结果只写入 `源码/rebuild-output` 和 `源码/frames`，不会安装或覆盖根目录最终文件。程序会检查重建图集RGBA等于根目录已确认图集。不同编码器版本可能影响WebP文件字节；正式迁移始终直接使用根目录已核验的原图集。

九种状态GIF、跑步全帧图和全状态对照图位于“预览”；本次原校验报告位于“验证记录”。这些资料用于检查和维护，不属于本地宠物目录的必需文件。

## 本次交付包测试范围

已在本机PowerShell 7的隔离目录验证资源校验、安装、重复运行、旧文件备份、写入失败回滚、无关文件保留和损坏资源拒绝；组装源码重建图集与根目录最终图集字节一致。本机Windows PowerShell 5.1受既有脚本执行策略阻止，未更改策略；该环境可按直接复制方式安装。未在另一台电脑或macOS/Linux实装。详见“验证记录/交付包测试.json”。
