from pathlib import Path
import importlib.util, json
from PIL import Image, ImageOps, ImageDraw

root=Path(__file__).resolve().parent
out=root.parent/'rebuilt'
out.mkdir(exist_ok=True)
scripts=root/'tools'
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
extract=module('extract',scripts/'extract_strip_frames.py')
extract.CELL_WIDTH,extract.CELL_HEIGHT=184,200
source=Image.open(root/'repaired-source.png').convert('RGBA')
groups=extract.component_frame_groups(source,8)
assert groups is not None and len(groups)==8
poses=extract.fit_registered_component_groups(source,groups)
original=Image.open(root/'current.webp').convert('RGBA')
atlas=original.copy()
for i,pose in enumerate(poses):
    frame=Image.new('RGBA',(192,208));frame.alpha_composite(pose,(4,8))
    atlas.paste(frame,(i*192,208));atlas.paste(ImageOps.mirror(frame),(i*192,416))
atlas.save(out/'spritesheet.webp',lossless=True,exact=True)
final=Image.open(out/'spritesheet.webp').convert('RGBA')
for row in [0,3,4,5,6,7,8]:
    box=(0,row*208,1536,(row+1)*208)
    assert final.crop(box).tobytes()==original.crop(box).tobytes()
for i in range(8):
    assert final.crop((i*192,416,(i+1)*192,624)).tobytes()==ImageOps.mirror(final.crop((i*192,208,(i+1)*192,416))).tobytes()
counts=[6,8,8,4,5,8,6,6,6]
states=['idle','running-right','running-left','waving','jumping','failed','waiting','running','review']
for row,(state,count) in enumerate(zip(states,counts)):
    directory=root/'frames'/state;directory.mkdir(parents=True,exist_ok=True)
    for i in range(count):final.crop((i*192,row*208,(i+1)*192,(row+1)*208)).save(directory/f'{i:02}.png')
    assert final.crop((count*192,row*208,1536,(row+1)*208)).getbbox() is None if count<8 else True

comparison=Image.new('RGB',(1536,4*236),'#e8e8e8');draw=ImageDraw.Draw(comparison)
for j,(label,im,row) in enumerate([('IDLE / unchanged',original,0),('RUN / before',original,1),('RUN / repaired candidate',final,1),('THINK / unchanged skin reference',original,7)]):
    strip=im.crop((0,row*208,1536,(row+1)*208));comparison.paste(strip,(0,j*236+28),strip);draw.text((8,j*236+7),label,fill='black')
comparison.save(out/'comparison.png')
panels=Image.new('RGB',(1152,440));d=ImageDraw.Draw(panels)
for i,bg in enumerate(['#151515','#888888','#ffffff']):
    panel=Image.new('RGBA',(384,416),bg);panel.alpha_composite(final.crop((0,208,192,416)).resize((384,416),Image.Resampling.NEAREST));panels.paste(panel.convert('RGB'),(384*i,24));d.text((384*i+8,5),bg,fill='white')
panels.save(out/'edge-backgrounds.png')
for row,state in [(1,'running-right'),(2,'running-left')]:
    frames=[final.crop((i*192,row*208,(i+1)*192,(row+1)*208)) for i in range(8)]
    frames[0].save(out/f'{state}.png',save_all=True,append_images=frames[1:],duration=120,loop=0,disposal=0,blend=0)
    # One shared palette and opaque review background avoid GIF edge and palette flicker.
    strip=Image.new('RGB',(1536,208),'#e8e8e8')
    for i,f in enumerate(frames):strip.paste(f,(i*192,0),f)
    indexed=strip.quantize(colors=255)
    gifs=[indexed.crop((i*192,0,(i+1)*192,208)) for i in range(8)]
    gifs[0].save(out/f'{state}.gif',save_all=True,append_images=gifs[1:],duration=120,loop=0,optimize=False)
(out/'checks.json').write_text(json.dumps({'changed_rows':[1,2],'seven_other_rows_rgba_identical':True,'framewise_mirror':True,'view_port':[184,200],'preview_duration_ms':120,'rebuild_only':True},indent=2))
print('Candidate assembled; unaffected rows preserved; eight mirrored frames checked.')
